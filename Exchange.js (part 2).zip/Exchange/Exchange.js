// ========== CREATE ITEM CARD ==========
function createItemCard(item) {
    var selected = isSelected(item);
    var condClass = 'condition-' + item.condition.replace(' ', '-');
    var selectBtnText = '+ Select';
    var selectBtnClass = 'btn-select';

    if (selected) {
        selectBtnText = '✓ Selected';
        selectBtnClass = 'btn-select selected-btn';
    }

    var cardClass = 'item-card';
    if (selected) {
        cardClass = 'item-card selected';
    }

    // Create card HTML
    var html = '<div class="' + cardClass + '">';
    html = html + '<img src="' + item.image + '" alt="' + item.name + '" onerror="this.src=\'https://via.placeholder.com/200?text=No+Image\'">';
    html = html + '<div class="name">' + item.name + '</div>';
    html = html + '<div class="brand">' + item.brand + '</div>';
    html = html + '<div class="price">' + formatPrice(item.price) + '</div>';
    html = html + '<span class="condition ' + condClass + '">' + item.condition + '</span>';
    html = html + '<span> ⭐ ' + item.rating + '</span><br>';
    html = html + '<button class="btn-view" onclick="viewItem(\'' + item.id + '\')">View</button>';
    html = html + '<button class="' + selectBtnClass + '" onclick="selectItem(\'' + item.id + '\')">' + selectBtnText + '</button>';
    html = html + '</div>';

    return html;
}

// ========== SELECT ITEM BY ID ==========
function selectItem(id) {
    for (var i = 0; i < items.length; i++) {
        if (items[i].id === id) {
            toggleSelect(items[i]);
            break;
        }
    }
}

// ========== VIEW ITEM ==========
function viewItem(id) {
    var item = null;
    for (var i = 0; i < items.length; i++) {
        if (items[i].id === id) {
            item = items[i];
            break;
        }
    }
    if (item) {
        alert(
            'Name: ' + item.name + '\n' +
            'Brand: ' + item.brand + '\n' +
            'Price: ' + formatPrice(item.price) + '\n' +
            'Description: ' + item.description + '\n' +
            'Condition: ' + item.condition + '\n' +
            'Rating: ' + item.rating + ' ⭐\n' +
            'Location: ' + item.location + '\n' +
            'Views: ' + item.views
        );
    }
}

// ========== RENDER COLLECTIONS ==========
function renderCollections() {
    var filtered = getFilteredItems();
    var user1Items = [];
    var user2Items = [];

    for (var i = 0; i < filtered.length; i++) {
        if (filtered[i].owner === 'user1') {
            user1Items.push(filtered[i]);
        } else {
            user2Items.push(filtered[i]);
        }
    }

    // Titles
    document.getElementById('user1Title').innerHTML = users.user1.icon + ' ' + users.user1.name + "'s Items";
    document.getElementById('user2Title').innerHTML = users.user2.icon + ' ' + users.user2.name + "'s Items";

    // User 1 items
    var html1 = '';
    for (var i = 0; i < user1Items.length; i++) {
        html1 = html1 + createItemCard(user1Items[i]);
    }
    document.getElementById('user1Items').innerHTML = html1;

    // User 2 items
    var html2 = '';
    for (var i = 0; i < user2Items.length; i++) {
        html2 = html2 + createItemCard(user2Items[i]);
    }
    document.getElementById('user2Items').innerHTML = html2;
}

// ========== RENDER SUMMARY ==========
function renderSummary() {
    var total1 = 0;
    for (var i = 0; i < user1Exchange.length; i++) {
        total1 = total1 + user1Exchange[i].price;
    }

    var total2 = 0;
    for (var i = 0; i < user2Exchange.length; i++) {
        total2 = total2 + user2Exchange[i].price;
    }

    var bar = document.getElementById('summaryBar');
    var text = document.getElementById('summaryText');

    if (user1Exchange.length === 0 && user2Exchange.length === 0) {
        bar.style.display = 'none';
    } else {
        bar.style.display = 'flex';
        text.innerHTML = users.user1.name + ': ' + formatPrice(total1) + ' (' + user1Exchange.length + ' items) ↔ ' +
                         users.user2.name + ': ' + formatPrice(total2) + ' (' + user2Exchange.length + ' items)';
    }
}

// ========== DO EXCHANGE ==========
function doExchange() {
    if (user1Exchange.length === 0 && user2Exchange.length === 0) {
        alert('Please select items from both users first!');
        return;
    }

    var total1 = 0;
    var list1 = '';
    for (var i = 0; i < user1Exchange.length; i++) {
        total1 = total1 + user1Exchange[i].price;
        list1 = list1 + '- ' + user1Exchange[i].name + ' (' + formatPrice(user1Exchange[i].price) + ')\n';
    }

    var total2 = 0;
    var list2 = '';
    for (var i = 0; i < user2Exchange.length; i++) {
        total2 = total2 + user2Exchange[i].price;
        list2 = list2 + '- ' + user2Exchange[i].name + ' (' + formatPrice(user2Exchange[i].price) + ')\n';
    }

    var diff = Math.abs(total1 - total2);

    var msg = 'CONFIRM EXCHANGE?\n\n';
    msg = msg + users.user1.name + ' gives:\n' + (list1 || 'Nothing\n');
    msg = msg + 'Total: ' + formatPrice(total1) + '\n\n';
    msg = msg + users.user2.name + ' gives:\n' + (list2 || 'Nothing\n');
    msg = msg + 'Total: ' + formatPrice(total2) + '\n\n';
    msg = msg + 'Difference: ' + formatPrice(diff);

    if (confirm(msg)) {
        // Swap owners
        for (var i = 0; i < items.length; i++) {
            for (var j = 0; j < user1Exchange.length; j++) {
                if (items[i].id === user1Exchange[j].id) {
                    items[i].owner = 'user2';
                }
            }
            for (var j = 0; j < user2Exchange.length; j++) {
                if (items[i].id === user2Exchange[j].id) {
                    items[i].owner = 'user1';
                }
            }
        }

        user1Exchange = [];
        user2Exchange = [];
        renderAll();
        alert('✅ Exchange completed successfully!');
    }
}

// ========== UPDATE USER DISPLAY ==========
function updateUI() {
    var user = users[currentUser];
    document.getElementById('userIcon').innerText = user.icon;
    document.getElementById('userName').innerText = user.name;
    document.getElementById('userRating').innerText = user.rating;
}

// ========== SWITCH USER ==========
function switchUser() {
    if (currentUser === 'user1') {
        currentUser = 'user2';
    } else {
        currentUser = 'user1';
    }
    updateUI();
}

// ========== RENDER ALL ==========
function renderAll() {
    renderStats();
    renderCategories();
    renderCollections();
    renderSummary();
    updateUI();
}

// ========== START ==========
renderAll();